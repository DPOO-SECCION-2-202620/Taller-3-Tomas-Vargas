package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;

/**
 * Esta clase se utiliza para calcular las tarifas en temporada baja.
 * En temporada baja, los clientes que son personas naturales tienen una tarifa base diferente a la de los clientes corporativos.
 * Adicionalmente, los clientes corporativos tienen un descuento diferente según el tamaño (los clientes naturales no tienen descuento).
 */
public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas
{

    protected final int COSTO_POR_KM = 600;
    protected final int CORPORATIVO = 900;
    protected final double PEQ = 0.02;
    protected final double DESCUENTO_MEDI = 0.1;
    protected final double grande = 0.2;


    @Override
    public int calcularCostoBase( Vuelo vuelo, Cliente cliente )
    {
        int distancia = calcularDistanciaVuelo( vuelo.getRuta( ) );
        if( cliente instanceof ClienteCorporativo )
            return distancia * CORPORATIVO;
        else
            return distancia * COSTO_POR_KM;
    }

    @Override
    public double calcularPorcentajeDescuento( Cliente cliente )
    {
        if( cliente instanceof ClienteCorporativo )
        {
            ClienteCorporativo cc = ( ClienteCorporativo )cliente;
            switch( cc.getTamanoEmpresa( ) )
            {
                case ClienteCorporativo.PEQUENA:
                    return PEQ;
                case ClienteCorporativo.MEDIANA:
                    return DESCUENTO_MEDI;
                case ClienteCorporativo.GRANDE:
                    return grande;
                default:
                    return 0;
            }
        }
        return 0;
    }

}
